#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <signal.h>
#include <string.h>
#include <signal.h>
int main(int argc, char *argv[]){
	int status;

	pid_t pid;

	/* fork a child process */
	printf("process start to fork\n");
	pid=fork();

	if (pid==-1){
		perror("fork");
		exit(1);
	}

	else{
		//child process
		if(pid==0){
			sleep(0.5);
			printf("I am the child process,my pid is %d\n", getpid());
			int i;
			char *arg[argc];
			
			for(i=0;i<argc-1;i++){
				arg[i]=argv[i+1];
			}
			arg[argc-1]=NULL;
			printf("child process start to execute test program:\n");
			execve(arg[0],arg,NULL);

		}
		//parent process
		else{
			printf("I am the parent process,my pid is %d\n", getpid());
			waitpid(-1, &status, WUNTRACED);
			printf("Parent process receives SIGCHLD signal\n");
			if (WIFEXITED(status)){
				printf("normal termination with exit status= %d\n", WEXITSTATUS(status));
			}
			else if(WIFSIGNALED(status)){
				int signum = WTERMSIG(status);
				printf("chile process get %s signal\n", strsignal(signum));
			}
			else if(WIFSTOPPED(status)){
				int signum = WSTOPSIG(status);
				printf("child process get %s signal\n", strsignal(signum));
			}
			else{
				printf("child process continued\n");
			}
			
			exit(0);
		}
		
	}
	/* execute test program */ 
	
	/* wait for child process terminates */
	
	/* check child process'  termination status */
	
	return 0;
}
