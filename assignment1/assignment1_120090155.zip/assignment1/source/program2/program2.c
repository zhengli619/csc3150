#include <linux/module.h>
#include <linux/sched.h>
#include <linux/pid.h>
#include <linux/kthread.h>
#include <linux/kernel.h>
#include <linux/err.h>
#include <linux/slab.h>
#include <linux/printk.h>
#include <linux/jiffies.h>
#include <linux/kmod.h>
#include <linux/fs.h>
#include <linux/sched/signal.h>
#include <linux/sched/task.h>
void my_wait(pid_t pid);
int parse_status(int status);
const char *get_signal_name(int signal_num);
MODULE_LICENSE("GPL");


extern pid_t kernel_clone(struct kernel_clone_args *kargs);

// extern struct filename* getname_kernel(const char __user *filename);
extern int kernel_execve(const char *filename, const char *const argv[], const char *const envp[]);
extern int kernel_wait(pid_t pid, int *stat);



int my_exec(void *argc) {
    int ret;
    
    
    const char *const argv[] = { "/tmp/test", NULL };
    const char *const envp[] = { "HOME=/", "PATH=/sbin:/usr/sbin:/bin:/usr/bin", NULL };

    // printk(KERN_INFO "Child process (PID: %d) starts executing my_exec function.\n", current->pid);

    // 执行用户态程序
    
    ret = kernel_execve("/tmp/test", argv, envp);
    
    if (ret != 0) {
        printk(KERN_ERR "Failed to execute the user program. Error code: %d\n", ret);
    }
    else printk(KERN_INFO "child process");  // 输出执行结果


    return ret;
}


//implement fork function
int my_fork(void *argc){
    struct k_sigaction *k_action;
	pid_t pid;
    struct kernel_clone_args clone_args;
    int i;
	//set default sigaction for current process
	
	k_action = &current->sighand->action[0];
	for(i=0;i<_NSIG;i++){
		k_action->sa.sa_handler = SIG_DFL;
		k_action->sa.sa_flags = 0;
		k_action->sa.sa_restorer = NULL;
		sigemptyset(&k_action->sa.sa_mask);
		k_action++;
	}
	
	


    // 设置 kernel_clone_args
    
    memset(&clone_args, 0, sizeof(clone_args));
    clone_args.flags = CLONE_VM | CLONE_FS | CLONE_FILES | SIGCHLD; // 设置子进程终止时发送 SIGCHLD
	clone_args.pidfd = NULL;
	clone_args.child_tid = NULL;
	clone_args.parent_tid = NULL;
	clone_args.exit_signal = SIGCHLD;
    clone_args.stack = (unsigned long)(&my_exec);  // 设置堆栈顶
    clone_args.stack_size = 0;
    clone_args.tls = 0;
        
        
    

    pid = kernel_clone(&clone_args);

	if (pid < 0) {
        printk(KERN_ERR "Failed to create child process using kernel_clone. ");
        return -1;
    }

    else{
    // 输出父进程和子进程的 PID
    
    printk(KERN_INFO "The child process has pid = %d\n", pid);
    printk(KERN_INFO "This is the parent process, pid =  %d\n", current->pid);

    
    my_wait(pid);

    
    }
  


	

	
	/* fork a process using kernel_clone or kernel_thread */
	
	/* execute a test program in child process */
	
	/* wait until child process terminates */
	
	return 0;
}

// implement wait function
void my_wait(pid_t pid) {
    int status;
    int ret;

    // 调用 kernel_wait 来等待子进程的退出
    ret = kernel_wait(pid, &status);  // 传递子进程的 PID 和指向 status 的指针

    // 打印返回值和子进程的退出状态
    // printk(KERN_INFO "kernel_wait return value is %d\n", ret);
    parse_status(status);
   

    return ;
}


const char *get_signal_name(int signal_num) {
        switch (signal_num) {
            case 1: return "SIGHUP";
            case 2: return "SIGINT";
            case 3: return "SIGQUIT";
            case 6: return "SIGABRT";
            case 9: return "SIGKILL";
            case 11: return "SIGSEGV";
            case 15: return "SIGTERM";
            case 19: return "SIGSTOP";
            case 20: return "SIGTSTP";
            case 7: return "SIGBUS";
            default: return "Unknown signal";
        }
    }


int parse_status(int status) {
        if (status & 0x7f) { // 检查是否由于信号终止
        int signal_num = status & 0x7f;
        const char *signal_name = get_signal_name(signal_num);
        printk("get %s signal\n", signal_name);
        printk("child process terminated\n");
        printk("The return signal is %d\n", signal_num);
    } else if ((status >> 8) & 0xff) { // 子进程被停止
        int stop_signal = (status >> 8) & 0xff;
        const char *stop_signal_name = get_signal_name(stop_signal);
        printk("get %s signal\n", stop_signal_name);
        printk("child process stopped\n");
        printk("The stop signal is %d\n", stop_signal);
    } else { // 正常退出
        int exit_code = (status >> 8) & 0xff;
        printk("Process exited with code: %d\n", exit_code);
    }
    return 0;
}
static int __init program2_init(void){
    static struct task_struct *task;

	printk("[program2] : Module_init\n");
	
	// 创建一个内核线程来运行 my_fork
    printk(KERN_INFO"module_init create kthread start");
	
    task = kthread_run(my_fork, NULL, "my_fork_thread");
    if (IS_ERR(task)) {
        printk(KERN_INFO "Failed to create kernel thread.\n");
        return PTR_ERR(task);

    }
    else{
        printk(KERN_INFO "module_init kthread start.\n");
    
	/* write your code here */
	
	/* create a kernel thread to run my_fork */
    }
	return 0;
}

static void __exit program2_exit(void){
	printk("[program2] : Module_exit\n");
}

module_init(program2_init);
module_exit(program2_exit);
